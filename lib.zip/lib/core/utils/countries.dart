// lib/features/profile/presentation/utils/countries.dart
const kCountries = <String>[
  'Nigeria',
  'Ghana',
  'Kenya',
  'South Africa',
  'United States',
  'United Kingdom',
  'Canada',
  'Germany',
  'France',
  'India',
  'Brazil',
];
