// lib/features/profile/domain/entities/profile.dart

class Profile {
  final String id;
  final String username;
  final String fullName;
  final String avatarUrl;
  final bool isVip;
  final int fans;
  final int allies;
  final int liveSessions;
  final int coins;
  final List<Club> clubs;
  final List<Post> posts;
  final List<LiveStream> liveStreams;

  Profile({
    required this.id,
    required this.username,
    required this.fullName,
    required this.avatarUrl,
    required this.isVip,
    required this.fans,
    required this.allies,
    required this.liveSessions,
    required this.coins,
    required this.clubs,
    required this.posts,
    required this.liveStreams,
  });
}

class Club {
  final String id;
  final String name;
  final String role;
  final int membersCount;
  final String lastActive;

  Club({
    required this.id,
    required this.name,
    required this.role,
    required this.membersCount,
    required this.lastActive,
  });
}

class Post {
  final String id;
  final String imageUrl;

  Post({required this.id, required this.imageUrl});
}

class LiveStream {
  final String id;
  final String title;
  final String thumbnailUrl;
  final int views;
  final String duration;
  final String timeAgo;

  LiveStream({
    required this.id,
    required this.title,
    required this.thumbnailUrl,
    required this.views,
    required this.duration,
    required this.timeAgo,
  });
}
