// lib/features/profile/presentation/pages/profile_page.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:moonlight/core/theme/app_colors.dart';
import '../bloc/profile_bloc.dart';
import '../../data/datasources/profile_local_data_source.dart';
import '../../data/datasources/profile_remote_data_source.dart';
import '../../data/repositories/profile_repository_impl.dart';

class ProfilePage extends StatefulWidget {
  final String userId;
  const ProfilePage({super.key, required this.userId});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);

    // Initialize Bloc with hybrid repository
    final profileBloc = ProfileBloc(
      repository: ProfileRepositoryImpl(
        localDataSource: ProfileLocalDataSourceImpl(),
        // remoteDataSource: ProfileRemoteDataSourceImpl(client: Dio()), // enable later
      ),
    );

    // Add FetchProfileEvent
    profileBloc.add(FetchProfileEvent(widget.userId));

    // Provide the bloc to the widget tree
    WidgetsBinding.instance.addPostFrameCallback((_) {
      BlocProvider.of<ProfileBloc>(
        context,
      ).add(FetchProfileEvent(widget.userId));
    });
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => ProfileBloc(
        repository: ProfileRepositoryImpl(
          localDataSource: ProfileLocalDataSourceImpl(),
        ),
      )..add(FetchProfileEvent(widget.userId)),
      child: Scaffold(
        body: BlocBuilder<ProfileBloc, ProfileState>(
          builder: (context, state) {
            if (state is ProfileLoading) {
              return const Center(child: CircularProgressIndicator());
            } else if (state is ProfileFailure) {
              return Center(child: Text(state.message));
            } else if (state is ProfileLoaded) {
              final profile = state.profile;
              return CustomScrollView(
                slivers: [
                  _buildProfileHeader(profile),
                  SliverFillRemaining(
                    child: TabBarView(
                      controller: _tabController,
                      children: [
                        _buildPostsTab(profile),
                        _buildClubsTab(profile),
                        _buildLivestreamTab(profile),
                      ],
                    ),
                  ),
                ],
              );
            }
            return const SizedBox.shrink();
          },
        ),
      ),
    );
  }

  SliverAppBar _buildProfileHeader(profile) {
    return SliverAppBar(
      pinned: true,
      expandedHeight: 280,
      backgroundColor: AppColors.primary,
      flexibleSpace: FlexibleSpaceBar(
        title: const Text('My Profile'),
        background: Column(
          children: [
            const SizedBox(height: 60),
            CircleAvatar(
              radius: 40,
              backgroundImage: NetworkImage(profile.avatarUrl),
            ),
            const SizedBox(height: 8),
            Text(
              '@${profile.username}',
              style: const TextStyle(color: Colors.white),
            ),
            Text(
              profile.fullName,
              style: const TextStyle(color: Colors.white70),
            ),
            const SizedBox(height: 8),
            if (profile.isVip)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.orange,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text('VIP', style: TextStyle(color: Colors.white)),
              ),
          ],
        ),
      ),
      bottom: TabBar(
        controller: _tabController,
        tabs: const [
          Tab(text: 'Posts'),
          Tab(text: 'Clubs'),
          Tab(text: 'Livestream'),
        ],
      ),
    );
  }

  Widget _buildPostsTab(profile) => GridView.builder(
    padding: const EdgeInsets.all(16),
    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: 3,
      crossAxisSpacing: 8,
      mainAxisSpacing: 8,
    ),
    itemCount: profile.posts.length,
    itemBuilder: (context, index) =>
        Image.network(profile.posts[index].imageUrl, fit: BoxFit.cover),
  );

  Widget _buildClubsTab(profile) => ListView.builder(
    padding: const EdgeInsets.all(16),
    itemCount: profile.clubs.length,
    itemBuilder: (context, index) {
      final club = profile.clubs[index];
      return Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: ListTile(
          leading: CircleAvatar(child: Text(club.name[0])),
          title: Text(club.name),
          subtitle: Text(
            '${club.membersCount} members · Active ${club.lastActive}',
          ),
          trailing: ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
              backgroundColor: club.role == 'President'
                  ? AppColors.secondary
                  : Colors.white,
              foregroundColor: club.role == 'President'
                  ? Colors.white
                  : Colors.black,
            ),
            child: Text(club.role == 'President' ? 'Manage Club' : 'Open Club'),
          ),
        ),
      );
    },
  );

  Widget _buildLivestreamTab(profile) => ListView.builder(
    padding: const EdgeInsets.all(16),
    itemCount: profile.liveStreams.length,
    itemBuilder: (context, index) {
      final ls = profile.liveStreams[index];
      return Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                Image.network(
                  ls.thumbnailUrl,
                  width: double.infinity,
                  height: 180,
                  fit: BoxFit.cover,
                ),
                Positioned(
                  top: 8,
                  left: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 6,
                      vertical: 2,
                    ),
                    color: Colors.red,
                    child: const Text(
                      'LIVE REPLAY',
                      style: TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 6,
                      vertical: 2,
                    ),
                    color: Colors.black45,
                    child: Text(
                      ls.duration,
                      style: const TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Text(
                ls.title,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Text(
                '${ls.views} views · ${ls.timeAgo}',
                style: const TextStyle(color: Colors.grey),
              ),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.secondary,
                ),
                child: const Text('Watch Replay'),
              ),
            ),
          ],
        ),
      );
    },
  );
}
