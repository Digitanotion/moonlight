// import 'package:flutter/material.dart';
// import 'package:moonlight/features/auth/presentation/pages/splash_screen.dart';
// import 'package:moonlight/features/auth/presentation/pages/login_screen.dart';

// class AppRouter {
//   static const String splash = '/';
//   static const String login = '/login';
//   static const String home = '/home';

//   static Route<dynamic> generateRoute(RouteSettings settings) {
//     switch (settings.name) {
//       case splash:
//         return MaterialPageRoute(builder: (_) => const SplashScreen());
//       case login:
//         return MaterialPageRoute(builder: (_) => const LoginScreen());
//       default:
//         return MaterialPageRoute(
//           builder: (_) => Scaffold(
//             body: Center(child: Text('No route defined for ${settings.name}')),
//           ),
//         );
//     }
//   }
// }
