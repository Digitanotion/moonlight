import 'dart:convert';
import 'package:moonlight/features/auth/data/models/user_model.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:moonlight/core/errors/exceptions.dart';

abstract class AuthLocalDataSource {
  Future<String?> getAuthToken();
  Future<void> cacheToken(String token);
  Future<void> clearToken();
  Future<void> cacheUser(UserModel user);
  Future<UserModel> getCurrentUser();
  Future<void> clearUserData();
}

class AuthLocalDataSourceImpl implements AuthLocalDataSource {
  final SharedPreferences sharedPreferences;

  AuthLocalDataSourceImpl({required this.sharedPreferences});

  static const String _tokenKey = 'auth_token';
  static const String _userKey = 'user_data';

  @override
  Future<String?> getAuthToken() async {
    return sharedPreferences.getString(_tokenKey);
  }

  @override
  Future<void> cacheToken(String token) async {
    await sharedPreferences.setString(_tokenKey, token);
  }

  @override
  Future<void> clearToken() async {
    await sharedPreferences.remove(_tokenKey);
  }

  @override
  Future<void> cacheUser(UserModel user) async {
    try {
      final userJson = jsonEncode(user.toJson());
      await sharedPreferences.setString(_userKey, userJson);
    } catch (e) {
      throw CacheException('Failed to cache user: ${e.toString()}');
    }
  }

  @override
  Future<UserModel> getCurrentUser() async {
    try {
      final jsonString = sharedPreferences.getString(_userKey);
      if (jsonString == null) {
        throw CacheException('No cached user found');
      }
      final Map<String, dynamic> userMap = jsonDecode(jsonString);
      return UserModel.fromJson(userMap);
    } catch (e) {
      if (e is CacheException) throw e;
      throw CacheException('Failed to retrieve cached user: ${e.toString()}');
    }
  }

  @override
  Future<void> clearUserData() async {
    await sharedPreferences.remove(_userKey);
  }
}
