// lib/features/profile/data/datasources/profile_remote_data_source.dart

import 'package:dio/dio.dart';
import '../../domain/entities/profile.dart';
import 'package:moonlight/core/errors/exceptions.dart';

abstract class ProfileRemoteDataSource {
  Future<Profile> fetchProfile(String userId);
}

class ProfileRemoteDataSourceImpl implements ProfileRemoteDataSource {
  final Dio client;

  ProfileRemoteDataSourceImpl({required this.client});

  @override
  Future<Profile> fetchProfile(String userId) async {
    try {
      final response = await client.get(
        'https://svc.moonlightstream.app/api/v1/profile/$userId',
      );

      final data = response.data as Map<String, dynamic>? ?? {};

      return Profile(
        id: data['id']?.toString() ?? '',
        username: data['username'] ?? 'Unknown',
        fullName: data['full_name'] ?? '',
        avatarUrl: data['avatar_url'] ?? '',
        isVip: data['is_vip'] ?? false,
        fans: data['fans'] ?? 0,
        allies: data['allies'] ?? 0,
        liveSessions: data['live_sessions'] ?? 0,
        coins: data['coins'] ?? 0,
        clubs: (data['clubs'] as List<dynamic>? ?? []).map((e) {
          final club = e as Map<String, dynamic>? ?? {};
          return Club(
            id: club['id']?.toString() ?? '',
            name: club['name'] ?? '',
            role: club['role'] ?? '',
            membersCount: club['members_count'] ?? 0,
            lastActive: club['last_active'] ?? '',
          );
        }).toList(),
        posts: (data['posts'] as List<dynamic>? ?? []).map((e) {
          final post = e as Map<String, dynamic>? ?? {};
          return Post(
            id: post['id']?.toString() ?? '',
            imageUrl: post['image_url'] ?? '',
          );
        }).toList(),
        liveStreams: (data['live_streams'] as List<dynamic>? ?? []).map((e) {
          final stream = e as Map<String, dynamic>? ?? {};
          return LiveStream(
            id: stream['id']?.toString() ?? '',
            title: stream['title'] ?? '',
            thumbnailUrl: stream['thumbnail_url'] ?? '',
            views: stream['views'] ?? 0,
            duration: stream['duration'] ?? '',
            timeAgo: stream['time_ago'] ?? '',
          );
        }).toList(),
      );
    } on DioException catch (e) {
      throw ServerException(
        e.response?.data['message'] ?? 'Failed to fetch profile',
        statusCode: e.response?.statusCode,
      );
    }
  }
}
