// lib/features/profile/data/datasources/profile_local_data_source.dart

import '../../domain/entities/profile.dart';
import 'dart:async';

abstract class ProfileLocalDataSource {
  Future<Profile> fetchProfile(String userId);
}

class ProfileLocalDataSourceImpl implements ProfileLocalDataSource {
  @override
  Future<Profile> fetchProfile(String userId) async {
    await Future.delayed(Duration(milliseconds: 500)); // simulate delay

    return Profile(
      id: userId,
      username: 'mock_user',
      fullName: 'Mock User',
      avatarUrl: 'https://example.com/avatar.png',
      isVip: true,
      fans: 123,
      allies: 45,
      liveSessions: 2,
      coins: 100,
      clubs: [
        Club(
          id: '1',
          name: 'Mock Club',
          role: 'Admin',
          membersCount: 50,
          lastActive: '1h ago',
        ),
      ],
      posts: [
        Post(id: '1', imageUrl: 'https://example.com/post1.png'),
        Post(id: '2', imageUrl: 'https://example.com/post2.png'),
      ],
      liveStreams: [
        LiveStream(
          id: '1',
          title: 'Mock Stream',
          thumbnailUrl: 'https://example.com/thumbnail.png',
          views: 200,
          duration: '15:30',
          timeAgo: '2h ago',
        ),
      ],
    );
  }
}
