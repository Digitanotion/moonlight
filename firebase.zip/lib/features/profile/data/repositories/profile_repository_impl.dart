// lib/features/profile/data/repositories/profile_repository_impl.dart

import 'package:dartz/dartz.dart';
import '../../domain/entities/profile.dart';
import '../../domain/repositories/profile_repository.dart';
import '../datasources/profile_local_data_source.dart';
import '../datasources/profile_remote_data_source.dart';
import 'package:moonlight/core/errors/failures.dart';

class ProfileRepositoryImpl implements ProfileRepository {
  final ProfileLocalDataSource localDataSource;
  final ProfileRemoteDataSource? remoteDataSource; // optional for now

  ProfileRepositoryImpl({required this.localDataSource, this.remoteDataSource});

  @override
  Future<Either<Failure, Profile>> getUserProfile(String userId) async {
    try {
      // 1️⃣ Try fetching local mock data
      final localProfile = await localDataSource.fetchProfile(userId);

      // 2️⃣ Try remote if available
      if (remoteDataSource != null) {
        try {
          final remoteProfile = await remoteDataSource!.fetchProfile(userId);
          return Right(remoteProfile);
        } catch (_) {
          // fallback to local if remote fails
          return Right(localProfile);
        }
      }

      return Right(localProfile);
    } catch (e) {
      return Left(ServerFailure("Failed to get user profile"));
    }
  }
}
